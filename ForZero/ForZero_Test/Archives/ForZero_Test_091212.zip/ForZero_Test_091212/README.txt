ForZero_Test download should include the following files:

* ForZero_Test application
* fz_download_awk0.txt
* fz_download_script2.sh
* fz_send_data_tcp
* lame
* this README.txt
